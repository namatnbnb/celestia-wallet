# Celestia Desktop Wallet

A secure, non-custodial desktop wallet for the Celestia network built with React, TypeScript, and Vite.

![Celestia Wallet](https://raw.githubusercontent.com/yourusername/celestia-wallet/main/screenshots/wallet-preview.png)

## Features

- 🔒 Non-custodial wallet with client-side key generation
- 💳 Create or import wallets using 24-word mnemonic phrases
- 💸 Send and receive TIA tokens
- 📊 Real-time balance updates
- 🔍 Transaction history with explorer integration
- 📱 QR code generation for receiving tokens
- 🌐 Multiple network endpoint support with automatic failover
- 🛡️ Advanced security features and input validation

## Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- CosmJS
- Lucide Icons

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Security Features

- Client-side key generation and transaction signing
- No server storage of sensitive data
- Automatic session timeout
- Input validation and sanitization
- Protection against replay attacks
- 24-word mnemonic (256-bit entropy)
- Hardened key derivation
- Transaction simulation
- Gas estimation safety buffer

## Network Integration

The wallet integrates with Celestia network through:
- REST API endpoints for account queries
- RPC nodes for transaction broadcasting
- WebSocket connections for real-time updates

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.