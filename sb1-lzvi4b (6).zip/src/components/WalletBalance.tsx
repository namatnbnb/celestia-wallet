import React, { useState, useEffect } from 'react';
import { RefreshCw, ExternalLink } from 'lucide-react';
import { APIClient } from '../utils/api-client';
import { CELESTIA_NETWORK } from '../utils/constants';
import TransactionHistory from './TransactionHistory';

interface WalletBalanceProps {
  address: string;
  balance: string;
  onBalanceUpdate: (balance: string) => void;
  onLoadingChange: (loading: boolean) => void;
}

const WalletBalance: React.FC<WalletBalanceProps> = ({ 
  address, 
  balance, 
  onBalanceUpdate,
  onLoadingChange 
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [lastUpdateTime, setLastUpdateTime] = useState<Date | null>(null);

  const updateBalance = async () => {
    if (!address || isLoading) return;

    setIsLoading(true);
    onLoadingChange(true);
    setError('');

    try {
      const newBalance = await APIClient.fetchBalance(address);
      onBalanceUpdate(newBalance);
      setLastUpdateTime(new Date());
      
      if (parseFloat(newBalance) === 0) {
        setError('No TIA tokens found in this wallet.');
      }
    } catch (err) {
      setError('Unable to fetch latest balance. Using cached data if available.');
    } finally {
      setIsLoading(false);
      onLoadingChange(false);
    }
  };

  useEffect(() => {
    if (!address) return;

    updateBalance();
    const interval = setInterval(updateBalance, 30000);
    return () => clearInterval(interval);
  }, [address]);

  if (!address) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-400">
          No wallet loaded. Please create or import a wallet to view balance.
        </p>
      </div>
    );
  }

  const lastUpdate = lastUpdateTime ? new Intl.DateTimeFormat('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(lastUpdateTime) : null;

  const explorerUrl = `${CELESTIA_NETWORK.explorerUrl}/account/${address}`;

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold">Wallet Balance</h2>
        <div className="flex items-center space-x-4">
          {lastUpdate && (
            <span className="text-sm text-gray-400">
              Last updated: {lastUpdate}
            </span>
          )}
          <button
            onClick={updateBalance}
            disabled={isLoading}
            className="flex items-center space-x-2 text-gray-400 hover:text-white disabled:opacity-50"
          >
            <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>{isLoading ? 'Refreshing...' : 'Refresh'}</span>
          </button>
        </div>
      </div>

      <div className="bg-gray-900 rounded-lg p-6 mb-6">
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Wallet Address
          </label>
          <div className="bg-gray-800 p-3 rounded-lg break-all font-mono text-sm">
            {address}
          </div>
          <a
            href={explorerUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-1 text-blue-400 hover:text-blue-300 mt-2 text-sm"
          >
            <span>View in Explorer</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Available Balance
          </label>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-bold">{balance}</span>
            <span className="text-gray-400">TIA</span>
          </div>
          {isLoading && (
            <p className="text-blue-400 text-sm mt-2">Updating balance...</p>
          )}
          {error && !isLoading && (
            <div className="mt-4 bg-yellow-900/20 border border-yellow-700/50 rounded-lg p-3">
              <p className="text-yellow-500 text-sm">{error}</p>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-gray-900 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2">Staked Balance</h3>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold">0.000000</span>
            <span className="text-gray-400">TIA</span>
          </div>
        </div>

        <div className="bg-gray-900 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2">Rewards</h3>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold">0.000000</span>
            <span className="text-gray-400">TIA</span>
          </div>
        </div>
      </div>

      <TransactionHistory address={address} />
    </div>
  );
};

export default WalletBalance;