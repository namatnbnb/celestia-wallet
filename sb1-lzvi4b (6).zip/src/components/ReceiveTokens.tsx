import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Copy } from 'lucide-react';

interface ReceiveTokensProps {
  address: string;
}

const ReceiveTokens: React.FC<ReceiveTokensProps> = ({ address }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!address) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-400">
          No wallet loaded. Please create or import a wallet to receive tokens.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Receive Tokens</h2>

      <div className="bg-gray-900 rounded-lg p-6 text-center mb-6">
        <div className="mb-6">
          <QRCodeSVG
            value={address}
            size={200}
            level="H"
            className="mx-auto bg-white p-2 rounded-lg"
          />
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Your Wallet Address
          </label>
          <div className="bg-gray-800 p-3 rounded-lg break-all font-mono text-sm mb-2">
            {address}
          </div>
          <button
            onClick={handleCopy}
            className="flex items-center space-x-2 mx-auto text-gray-400 hover:text-white"
          >
            <Copy className="w-4 h-4" />
            <span>{copied ? 'Copied!' : 'Copy Address'}</span>
          </button>
        </div>
      </div>

      <div className="bg-blue-900/20 border border-blue-700/50 p-4 rounded-lg">
        <p className="text-blue-400 text-sm">
          Share your wallet address or QR code with others to receive TIA tokens. Only send Celestia (TIA) tokens to this address.
        </p>
      </div>
    </div>
  );
};

export default ReceiveTokens;