import React from 'react';
import { ExternalLink } from 'lucide-react';
import { CELESTIA_NETWORK } from '../utils/constants';

interface TransactionHistoryProps {
  address: string;
}

const TransactionHistory: React.FC<TransactionHistoryProps> = ({ address }) => {
  if (!address) {
    return null;
  }

  const explorerUrl = `${CELESTIA_NETWORK.explorerUrl}/account/${address}`;

  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Transaction History</h2>
        <a
          href={explorerUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors"
        >
          <span>View Full History</span>
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>

      <div className="bg-gray-900 rounded-lg p-6">
        <div className="text-center">
          <p className="text-gray-400 mb-4">
            View your complete transaction history in the Celestia Explorer
          </p>
          <a
            href={explorerUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
          >
            <span>Open in Explorer</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default TransactionHistory;