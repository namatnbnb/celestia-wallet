import React, { useState } from 'react';
import { Shield, Lock, AlertTriangle, CheckCircle } from 'lucide-react';

interface HomePageProps {
  onAccept: () => void;
}

const HomePage: React.FC<HomePageProps> = ({ onAccept }) => {
  const [accepted, setAccepted] = useState(false);

  const handleAccept = () => {
    if (accepted) {
      onAccept();
    }
  };

  return (
    <div className="max-w-4xl mx-auto text-gray-100">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Welcome to Celestia Wallet</h1>
        <p className="text-xl text-gray-400">A secure, non-custodial wallet for the Celestia network</p>
      </div>

      <div className="space-y-8">
        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <Shield className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">About Celestia Wallet</h2>
              <p className="text-gray-300 mb-4">
                Celestia Wallet is a decentralized cryptocurrency wallet that allows you to securely store, send, and receive TIA tokens on the Celestia network. This wallet provides direct access to the blockchain without holding your keys.
              </p>
              <ul className="list-disc list-inside text-gray-300 space-y-2">
                <li>Non-custodial: You have full control of your funds</li>
                <li>Secure: Your private keys never leave your device</li>
                <li>Open-source: Transparent and community-driven</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <Lock className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Security Features</h2>
              <ul className="space-y-3 text-gray-300">
                <li>• 24-word recovery phrase for maximum security</li>
                <li>• Client-side encryption and key generation</li>
                <li>• No storage of private keys or personal data</li>
                <li>• Automatic session timeout for added protection</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <AlertTriangle className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Important Risks & Considerations</h2>
              <ul className="space-y-3 text-gray-300">
                <li>• Your recovery phrase is the only way to access your wallet - store it safely</li>
                <li>• Lost or stolen recovery phrases cannot be recovered</li>
                <li>• Always verify transaction details before sending</li>
                <li>• Be cautious of phishing attempts and fake websites</li>
                <li>• Never share your recovery phrase with anyone</li>
              </ul>
            </div>
          </div>
        </section>

        <div className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <CheckCircle className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Privacy Policy</h2>
              <p className="text-gray-300 mb-4">
                We are committed to protecting your privacy:
              </p>
              <ul className="list-disc list-inside text-gray-300 space-y-2">
                <li>No personal information is collected or stored</li>
                <li>No tracking or analytics</li>
                <li>All operations are performed locally on your device</li>
                <li>No external servers are used for wallet operations</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <input
              type="checkbox"
              id="accept"
              checked={accepted}
              onChange={(e) => setAccepted(e.target.checked)}
              className="w-4 h-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="accept" className="text-gray-300">
              I understand the risks and accept the terms
            </label>
          </div>

          <button
            onClick={handleAccept}
            disabled={!accepted}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-600/50 disabled:cursor-not-allowed text-white font-bold py-4 px-6 rounded-lg transition-colors"
          >
            Enter Wallet
          </button>
        </div>
      </div>
    </div>
  );
};

export default HomePage;