import React, { useState, useEffect } from 'react';
import { Copy, RefreshCw } from 'lucide-react';
import { generateMnemonic, createWallet } from '../utils/crypto';

interface CreateWalletProps {
  onWalletCreated: (address: string, mnemonic: string) => void;
}

const CreateWallet: React.FC<CreateWalletProps> = ({ onWalletCreated }) => {
  const [mnemonic, setMnemonic] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);

  const generateNewWallet = async () => {
    setError('');
    setLoading(true);
    try {
      const newMnemonic = await generateMnemonic();
      setMnemonic(newMnemonic);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generateNewWallet();
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(mnemonic);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCreate = async () => {
    if (!mnemonic) {
      setError('Please generate a recovery phrase first');
      return;
    }
    
    setLoading(true);
    try {
      const wallet = await createWallet(mnemonic);
      onWalletCreated(wallet.address, mnemonic);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Create New Wallet</h2>
      
      <div className="bg-gray-900 p-6 rounded-lg mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Recovery Phrase</h3>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1 text-sm text-gray-400 hover:text-white"
              disabled={!mnemonic || loading}
            >
              <Copy className="w-4 h-4" />
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={generateNewWallet}
              className="flex items-center space-x-1 text-sm text-gray-400 hover:text-white"
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Generate New</span>
            </button>
          </div>
        </div>
        
        {loading ? (
          <div className="text-center py-8">
            <p className="text-gray-400">Generating secure wallet...</p>
          </div>
        ) : mnemonic ? (
          <div className="grid grid-cols-3 gap-4">
            {mnemonic.split(' ').map((word, index) => (
              <div key={index} className="bg-gray-800 p-2 rounded flex items-center">
                <span className="text-gray-500 mr-2">{index + 1}.</span>
                <span>{word}</span>
              </div>
            ))}
          </div>
        ) : null}
      </div>

      {error && (
        <div className="bg-red-900/20 border border-red-700/50 p-4 rounded-lg mb-6">
          <p className="text-red-500 text-sm">{error}</p>
        </div>
      )}

      <div className="bg-yellow-900/20 border border-yellow-700/50 p-4 rounded-lg mb-6">
        <p className="text-yellow-500 text-sm">
          ⚠️ Write down your recovery phrase and store it in a safe place. This is the only way to recover your wallet if you lose access.
        </p>
      </div>

      <button
        onClick={handleCreate}
        disabled={!mnemonic || loading}
        className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-600/50 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-colors"
      >
        {loading ? 'Creating Wallet...' : 'Create Wallet'}
      </button>
    </div>
  );
};

export default CreateWallet;