import React, { useState } from 'react';
import { createWallet } from '../utils/crypto';

interface ImportWalletProps {
  onWalletImported: (address: string, mnemonic: string) => void;
}

const ImportWallet: React.FC<ImportWalletProps> = ({ onWalletImported }) => {
  const [mnemonic, setMnemonic] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleImport = async () => {
    if (!mnemonic.trim()) {
      setError('Please enter your recovery phrase');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const wallet = await createWallet(mnemonic.trim());
      onWalletImported(wallet.address, mnemonic.trim());
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Import Existing Wallet</h2>
      
      <div className="mb-6">
        <label className="block text-sm font-medium mb-2">
          Recovery Phrase
        </label>
        <textarea
          value={mnemonic}
          onChange={(e) => {
            setMnemonic(e.target.value);
            setError('');
          }}
          disabled={loading}
          className="w-full bg-gray-900 border border-gray-700 rounded-lg p-4 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 disabled:opacity-50"
          placeholder="Enter your 24-word recovery phrase"
          rows={4}
        />
        {error && (
          <p className="mt-2 text-red-500 text-sm">{error}</p>
        )}
      </div>

      <div className="bg-gray-900/50 border border-gray-700 p-4 rounded-lg mb-6">
        <p className="text-gray-400 text-sm">
          Enter the recovery phrase of your existing wallet. Words should be separated by spaces.
        </p>
      </div>

      <button
        onClick={handleImport}
        disabled={loading || !mnemonic.trim()}
        className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-600/50 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-colors"
      >
        {loading ? 'Importing...' : 'Import Wallet'}
      </button>
    </div>
  );
};

export default ImportWallet;