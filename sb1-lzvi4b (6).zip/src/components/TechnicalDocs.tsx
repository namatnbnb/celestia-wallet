import React from 'react';
import { Code, Shield, Cpu, Network, Wallet, Layers, GitBranch, Zap } from 'lucide-react';

const TechnicalDocs = () => {
  return (
    <div className="max-w-4xl mx-auto text-gray-100">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Technical Documentation</h1>
        <p className="text-xl text-gray-400">Comprehensive technical details and specifications</p>
      </div>

      <div className="space-y-8">
        {/* Architecture Overview */}
        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <Layers className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Architecture Overview</h2>
              <div className="space-y-4 text-gray-300">
                <p>
                  This wallet is built as a non-custodial, client-side application using modern web technologies:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>React for UI components and state management</li>
                  <li>TypeScript for type-safe code</li>
                  <li>Tailwind CSS for styling</li>
                  <li>Vite for building and development</li>
                </ul>
                <div className="bg-gray-900 p-4 rounded-lg mt-4">
                  <pre className="text-sm overflow-x-auto">
                    App
                    ├── Components
                    │   ├── CreateWallet
                    │   ├── ImportWallet
                    │   ├── SendTokens
                    │   ├── ReceiveTokens
                    │   ├── WalletBalance
                    │   └── TransactionHistory
                    ├── Utils
                    │   ├── api-client
                    │   ├── crypto
                    │   ├── transaction-client
                    │   └── constants
                    └── Services
                        └── Network Interfaces
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Cryptographic Implementation */}
        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <Shield className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Cryptographic Implementation</h2>
              <div className="space-y-4 text-gray-300">
                <ul className="space-y-3">
                  <li>• Uses <code>@cosmjs/crypto</code> for cryptographic operations</li>
                  <li>• Implements BIP39 for mnemonic generation (24 words)</li>
                  <li>• Follows BIP44 for HD wallet derivation</li>
                  <li>• Path: m/44'/118'/0'/0/0 (Celestia)</li>
                  <li>• Secp256k1 elliptic curve for key generation</li>
                </ul>
                <div className="bg-gray-900 p-4 rounded-lg mt-2">
                  <code className="text-sm">
                    const wallet = await DirectSecp256k1HdWallet.fromMnemonic(mnemonic, {'{'}
                      prefix: 'celestia',
                      hdPaths: [stringToPath("m/44'/118'/0'/0/0")]
                    {'}'});
                  </code>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Network Integration */}
        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <Network className="w-6 h-6 text-purple-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Network Integration</h2>
              <div className="space-y-4 text-gray-300">
                <p>The wallet integrates with Celestia network through:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>REST API endpoints for account queries</li>
                  <li>RPC nodes for transaction broadcasting</li>
                  <li>WebSocket connections for real-time updates</li>
                </ul>
                <div className="bg-gray-900 p-4 rounded-lg">
                  <p className="text-sm mb-2">Supported Endpoints:</p>
                  <ul className="text-sm space-y-1">
                    <li>• REST: api.celestia.nodestake.top</li>
                    <li>• RPC: rpc.celestia.nodestake.top</li>
                    <li>• WebSocket: wss://celestia-rpc.publicnode.com</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Transaction Handling */}
        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <Zap className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Transaction Handling</h2>
              <div className="space-y-4 text-gray-300">
                <ul className="space-y-3">
                  <li>• Implements Cosmos SDK transaction protocol</li>
                  <li>• Automatic gas estimation and fee calculation</li>
                  <li>• Transaction simulation before broadcast</li>
                  <li>• Supports memo field for transaction notes</li>
                  <li>• Implements timeout height for transaction safety</li>
                </ul>
                <div className="bg-gray-900 p-4 rounded-lg">
                  <p className="text-sm mb-2">Gas Estimation:</p>
                  <code className="text-sm">
                    estimatedGas = simulatedGas * 1.3 // 30% buffer
                  </code>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <Cpu className="w-6 h-6 text-red-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Technical FAQ</h2>
              <div className="space-y-6 text-gray-300">
                <div>
                  <h3 className="font-semibold mb-2">Q: How are private keys stored?</h3>
                  <p>Private keys are never stored directly. Only the encrypted mnemonic is temporarily held in localStorage during the session.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Q: What happens if a transaction fails?</h3>
                  <p>Failed transactions are simulated before broadcast. If simulation fails, the transaction is not sent. If broadcast fails, the error is caught and displayed with detailed information.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Q: How is the balance updated?</h3>
                  <p>Balance is fetched every 30 seconds using the Celestia REST API. WebSocket connections monitor for relevant transactions for real-time updates.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Q: What happens during network issues?</h3>
                  <p>The wallet implements automatic endpoint switching and retry mechanisms with exponential backoff.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Security Considerations */}
        <section className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <GitBranch className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold mb-3">Security Considerations</h2>
              <div className="space-y-4 text-gray-300">
                <ul className="list-disc list-inside space-y-2">
                  <li>Client-side key generation and signing</li>
                  <li>No server storage of sensitive data</li>
                  <li>Automatic session timeout</li>
                  <li>Input validation and sanitization</li>
                  <li>Protection against replay attacks</li>
                </ul>
                <div className="bg-gray-900 p-4 rounded-lg mt-2">
                  <p className="text-sm">Security Features:</p>
                  <ul className="text-sm mt-2 space-y-1">
                    <li>• 24-word mnemonic (256-bit entropy)</li>
                    <li>• Hardened key derivation</li>
                    <li>• Transaction simulation</li>
                    <li>• Gas estimation safety buffer</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default TechnicalDocs;