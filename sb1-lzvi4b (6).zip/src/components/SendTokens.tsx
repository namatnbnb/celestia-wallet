import React, { useState } from 'react';
import { Send, AlertTriangle } from 'lucide-react';
import { CELESTIA_NETWORK } from '../utils/constants';
import { TransactionClient } from '../utils/transaction-client';

interface SendTokensProps {
  address: string;
  balance: string;
}

const SendTokens: React.FC<SendTokensProps> = ({ address, balance }) => {
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [memo, setMemo] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState('');

  const validateInputs = () => {
    if (!recipient.trim()) {
      setError('Please enter a recipient address');
      return false;
    }

    if (!recipient.startsWith(CELESTIA_NETWORK.prefix)) {
      setError('Invalid recipient address. Must be a Celestia address.');
      return false;
    }

    if (!amount || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount');
      return false;
    }

    const amountFloat = parseFloat(amount);
    const balanceFloat = parseFloat(balance);

    if (amountFloat > balanceFloat) {
      setError('Insufficient balance');
      return false;
    }

    // Check for minimum amount (dust)
    if (amountFloat < 0.000001) {
      setError('Amount must be at least 0.000001 TIA');
      return false;
    }

    return true;
  };

  const handleSend = async () => {
    try {
      setError('');
      setSuccess('');
      
      if (!validateInputs()) {
        return;
      }

      setIsLoading(true);

      const tx = await TransactionClient.sendTokens({
        fromAddress: address,
        toAddress: recipient,
        amount: amount,
        memo: memo.trim()
      });

      setSuccess(`Transaction sent successfully! Hash: ${tx.hash}`);
      setAmount('');
      setRecipient('');
      setMemo('');
    } catch (err: any) {
      setError(err.message || 'Failed to send transaction. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!address) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-400">
          No wallet loaded. Please create or import a wallet to send tokens.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Send Tokens</h2>

      <div className="bg-gray-900 rounded-lg p-6 mb-6">
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">
            Available Balance
          </label>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold">{balance}</span>
            <span className="text-gray-400">TIA</span>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">
            Recipient Address
          </label>
          <input
            type="text"
            value={recipient}
            onChange={(e) => {
              setRecipient(e.target.value);
              setError('');
              setSuccess('');
            }}
            disabled={isLoading}
            className="w-full bg-gray-900 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 disabled:opacity-50"
            placeholder="celestia..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">
            Amount (TIA)
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => {
              setAmount(e.target.value);
              setError('');
              setSuccess('');
            }}
            disabled={isLoading}
            min="0.000001"
            step="0.000001"
            className="w-full bg-gray-900 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 disabled:opacity-50"
            placeholder="0.000000"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">
            Memo (Optional)
          </label>
          <input
            type="text"
            value={memo}
            onChange={(e) => setMemo(e.target.value)}
            disabled={isLoading}
            maxLength={256}
            className="w-full bg-gray-900 border border-gray-700 rounded-lg p-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 disabled:opacity-50"
            placeholder="Add a message to this transaction"
          />
        </div>

        {error && (
          <div className="bg-red-900/20 border border-red-700/50 p-4 rounded-lg flex items-start space-x-3">
            <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
            <p className="text-red-500 text-sm">{error}</p>
          </div>
        )}

        {success && (
          <div className="bg-green-900/20 border border-green-700/50 p-4 rounded-lg">
            <p className="text-green-500 text-sm">{success}</p>
          </div>
        )}

        <button
          onClick={handleSend}
          disabled={isLoading || !recipient || !amount}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-600/50 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2"
        >
          <Send className="w-5 h-5" />
          <span>{isLoading ? 'Sending...' : 'Send Tokens'}</span>
        </button>

        <div className="bg-yellow-900/20 border border-yellow-700/50 p-4 rounded-lg">
          <p className="text-yellow-500 text-sm">
            ⚠️ Double-check the recipient address before sending. Transactions cannot be reversed.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SendTokens;