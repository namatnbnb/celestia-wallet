export const CELESTIA_NETWORK = {
  chainId: 'celestia',
  prefix: 'celestia',
  coinType: 118,
  coinDenom: 'TIA',
  coinDecimals: 6,
  coinMinimalDenom: 'utia',
  endpoints: {
    rest: [
      'https://api.celestia.nodestake.top',
      'https://api.celestia.stakewith.us',
      'https://celestia-api.publicnode.com',
      'https://celestia-rest.publicnode.com',
      'https://celestia.api.kjnodes.com'
    ],
    rpc: [
      'https://rpc.celestia.nodestake.top',
      'https://rpc.celestia.stakewith.us',
      'https://celestia-rpc.publicnode.com',
      'https://celestia-rpc.publicnode.com',
      'https://celestia.rpc.kjnodes.com'
    ],
    wss: [
      'wss://celestia-rpc.publicnode.com:443/websocket',
      'wss://rpc.celestia.stakewith.us:443/websocket'
    ]
  },
  gasPrice: 0.1,
  explorerUrl: 'https://celestia.explorers.guru'
};