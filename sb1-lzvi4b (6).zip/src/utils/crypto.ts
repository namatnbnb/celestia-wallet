import { DirectSecp256k1HdWallet } from '@cosmjs/proto-signing';
import { stringToPath } from '@cosmjs/crypto';
import { generateMnemonic as genMnemonic, validateMnemonic } from 'bip39';

export interface WalletData {
  mnemonic: string;
  address: string;
}

const CELESTIA_PREFIX = 'celestia';
const CELESTIA_HD_PATH = "m/44'/118'/0'/0/0";

export async function generateMnemonic(): Promise<string> {
  try {
    return genMnemonic(256); // 24 words
  } catch (error) {
    console.error('Mnemonic generation error:', error);
    throw new Error('Failed to generate secure wallet. Please try again.');
  }
}

export async function createWallet(mnemonic: string): Promise<WalletData> {
  try {
    if (!validateMnemonic(mnemonic)) {
      throw new Error('Invalid recovery phrase');
    }

    const wallet = await DirectSecp256k1HdWallet.fromMnemonic(mnemonic, {
      prefix: CELESTIA_PREFIX,
      hdPaths: [stringToPath(CELESTIA_HD_PATH)],
    });

    const [account] = await wallet.getAccounts();
    
    if (!account?.address) {
      throw new Error('Failed to generate wallet address');
    }

    return {
      mnemonic,
      address: account.address,
    };
  } catch (error) {
    console.error('Wallet creation error:', error);
    throw new Error('Failed to create wallet. Please try again.');
  }
}