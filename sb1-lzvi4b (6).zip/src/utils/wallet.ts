import { DirectSecp256k1HdWallet } from '@cosmjs/proto-signing';
import { generateMnemonic as genMnemonic, validateMnemonic } from 'bip39';
import { CELESTIA_NETWORK } from './constants';

export interface WalletData {
  mnemonic: string;
  address: string;
}

const WALLET_OPTIONS = {
  prefix: CELESTIA_NETWORK.prefix,
  hdPaths: [[44, CELESTIA_NETWORK.coinType, 0, 0, 0]],
};

export async function generateWallet(): Promise<WalletData> {
  try {
    const mnemonic = genMnemonic(256); // 24 words for enhanced security
    const walletData = await createWalletFromMnemonic(mnemonic);
    return walletData;
  } catch (error: any) {
    console.error('Error generating wallet:', error);
    throw new Error(error?.message || 'Failed to generate wallet. Please try again.');
  }
}

export async function createWalletFromMnemonic(mnemonic: string): Promise<WalletData> {
  if (!validateMnemonic(mnemonic)) {
    throw new Error('Invalid recovery phrase. Please check and try again.');
  }

  try {
    const wallet = await DirectSecp256k1HdWallet.fromMnemonic(
      mnemonic,
      {
        prefix: WALLET_OPTIONS.prefix,
        hdPaths: WALLET_OPTIONS.hdPaths.map((path) => ({
          coinType: path[1],
          account: path[2],
          change: path[3],
          index: path[4],
        })),
      }
    );

    const [firstAccount] = await wallet.getAccounts();
    
    if (!firstAccount?.address) {
      throw new Error('Failed to generate wallet address');
    }

    return {
      mnemonic,
      address: firstAccount.address,
    };
  } catch (error: any) {
    console.error('Error creating wallet from mnemonic:', error);
    throw new Error(error?.message || 'Failed to create wallet. Please try again.');
  }
}

export async function fetchBalance(address: string): Promise<string> {
  try {
    const response = await fetch(`${CELESTIA_NETWORK.restEndpoint}/cosmos/bank/v1beta1/balances/${address}`);
    const data = await response.json();
    
    const balance = data.balances?.find((b: any) => b.denom === CELESTIA_NETWORK.coinMinimalDenom);
    if (!balance) {
      return '0';
    }

    // Convert from utia (microTIA) to TIA
    const tiaAmount = parseFloat(balance.amount) / Math.pow(10, CELESTIA_NETWORK.coinDecimals);
    return tiaAmount.toFixed(6);
  } catch (error) {
    console.error('Error fetching balance:', error);
    throw new Error('Failed to fetch balance. Please try again.');
  }
}