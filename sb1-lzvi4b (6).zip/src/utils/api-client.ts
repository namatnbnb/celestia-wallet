import { CELESTIA_NETWORK } from './constants';

interface Transaction {
  hash: string;
  type: 'sent' | 'received';
  amount: string;
  from: string;
  to: string;
  timestamp: string;
  status: 'success' | 'failed';
  fee: string;
  memo?: string;
}

interface TxResponse {
  tx_response: {
    txhash: string;
    code: number;
    timestamp: string;
    gas_used: string;
    gas_wanted: string;
    raw_log: string;
  };
  tx: {
    body: {
      messages: Array<{
        '@type': string;
        from_address: string;
        to_address: string;
        amount: Array<{
          denom: string;
          amount: string;
        }>;
      }>;
      memo: string;
    };
    auth_info: {
      fee: {
        amount: Array<{
          denom: string;
          amount: string;
        }>;
      };
    };
  };
}

export class APIClient {
  private static timeoutDuration = 10000;
  private static maxRetries = 3;
  private static retryDelay = 1000;
  private static cache = new Map<string, { data: any; timestamp: number }>();
  private static cacheExpiry = 30000; // 30 seconds
  private static endpointIndex = 0;

  private static getNextEndpoint(): string {
    const { endpoints } = CELESTIA_NETWORK;
    this.endpointIndex = (this.endpointIndex + 1) % endpoints.rest.length;
    return endpoints.rest[this.endpointIndex];
  }

  private static async fetchWithTimeout(
    url: string,
    options: RequestInit = {}
  ): Promise<Response> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeoutDuration);

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
          ...options.headers,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return response;
    } finally {
      clearTimeout(timeoutId);
    }
  }

  private static async fetchWithRetry<T>(
    url: string,
    options: RequestInit = {}
  ): Promise<T> {
    let lastError: Error | null = null;
    let currentUrl = url;

    for (let attempt = 0; attempt < this.maxRetries; attempt++) {
      try {
        const response = await this.fetchWithTimeout(currentUrl, options);
        return await response.json();
      } catch (error: any) {
        lastError = error;
        if (attempt < this.maxRetries - 1) {
          // Try next endpoint on failure
          currentUrl = currentUrl.replace(/^https?:\/\/[^\/]+/, this.getNextEndpoint());
          await new Promise(resolve => setTimeout(resolve, this.retryDelay * Math.pow(2, attempt)));
        }
      }
    }

    throw lastError || new Error('Failed after multiple attempts');
  }

  static async fetchBalance(address: string): Promise<string> {
    if (!address) return '0.000000';

    const cacheKey = `balance:${address}`;
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.cacheExpiry) {
      return cached.data;
    }

    try {
      const endpoint = this.getNextEndpoint();
      const data = await this.fetchWithRetry<any>(
        `${endpoint}/cosmos/bank/v1beta1/balances/${address}`
      );

      const balance = data.balances?.find(
        (b: any) => b.denom === CELESTIA_NETWORK.coinMinimalDenom
      );

      const amount = balance ? parseFloat(balance.amount) / Math.pow(10, CELESTIA_NETWORK.coinDecimals) : 0;
      const formattedBalance = amount.toFixed(6);

      this.cache.set(cacheKey, {
        data: formattedBalance,
        timestamp: Date.now()
      });

      return formattedBalance;
    } catch (error) {
      console.error('Error fetching balance:', error);
      const cached = this.cache.get(cacheKey);
      return cached ? cached.data : '0.000000';
    }
  }

  static async getTransactionHistory(address: string): Promise<Transaction[]> {
    if (!address) return [];

    const cacheKey = `transactions:${address}`;
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.cacheExpiry) {
      return cached.data;
    }

    try {
      const endpoint = this.getNextEndpoint();
      const [sentTxs, receivedTxs] = await Promise.all([
        this.fetchWithRetry<any>(
          `${endpoint}/cosmos/tx/v1beta1/txs?events=message.sender='${address}'&order_by=ORDER_BY_DESC&pagination.limit=50`
        ),
        this.fetchWithRetry<any>(
          `${endpoint}/cosmos/tx/v1beta1/txs?events=transfer.recipient='${address}'&order_by=ORDER_BY_DESC&pagination.limit=50`
        )
      ]);

      const transactions: Transaction[] = [];
      const processedHashes = new Set<string>();

      const processTx = (tx: TxResponse, type: 'sent' | 'received') => {
        if (processedHashes.has(tx.tx_response.txhash)) return;
        processedHashes.add(tx.tx_response.txhash);

        const message = tx.tx.body.messages[0];
        if (message['@type'] !== '/cosmos.bank.v1beta1.MsgSend') return;

        const amount = message.amount[0];
        if (amount.denom !== CELESTIA_NETWORK.coinMinimalDenom) return;

        const fee = tx.tx.auth_info.fee.amount[0];
        const feeAmount = fee ? 
          (parseFloat(fee.amount) / Math.pow(10, CELESTIA_NETWORK.coinDecimals)).toFixed(6) : 
          '0.000000';

        transactions.push({
          hash: tx.tx_response.txhash,
          type,
          amount: (parseFloat(amount.amount) / Math.pow(10, CELESTIA_NETWORK.coinDecimals)).toFixed(6),
          from: message.from_address,
          to: message.to_address,
          timestamp: tx.tx_response.timestamp,
          status: tx.tx_response.code === 0 ? 'success' : 'failed',
          fee: feeAmount,
          memo: tx.tx.body.memo || undefined
        });
      };

      sentTxs.tx_responses?.forEach((tx: TxResponse) => processTx(tx, 'sent'));
      receivedTxs.tx_responses?.forEach((tx: TxResponse) => processTx(tx, 'received'));

      transactions.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );

      this.cache.set(cacheKey, {
        data: transactions,
        timestamp: Date.now()
      });

      return transactions;
    } catch (error) {
      console.error('Error fetching transactions:', error);
      const cached = this.cache.get(cacheKey);
      return cached ? cached.data : [];
    }
  }

  static clearCache(): void {
    this.cache.clear();
  }
}