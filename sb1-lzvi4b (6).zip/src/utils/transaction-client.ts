import { DirectSecp256k1HdWallet } from '@cosmjs/proto-signing';
import { SigningStargateClient } from '@cosmjs/stargate';
import { CELESTIA_NETWORK } from './constants';

interface SendTokensParams {
  fromAddress: string;
  toAddress: string;
  amount: string;
  memo?: string;
}

interface TransactionResult {
  hash: string;
  height?: number;
}

export class TransactionClient {
  private static timeoutHeight = 100; // blocks
  private static gasMultiplier = 1.3;
  private static endpointIndex = 0;

  private static getNextEndpoint(): string {
    const { endpoints } = CELESTIA_NETWORK;
    this.endpointIndex = (this.endpointIndex + 1) % endpoints.rpc.length;
    return endpoints.rpc[this.endpointIndex];
  }

  private static async getSigningClient(mnemonic: string): Promise<SigningStargateClient> {
    try {
      const wallet = await DirectSecp256k1HdWallet.fromMnemonic(mnemonic, {
        prefix: CELESTIA_NETWORK.prefix
      });

      const endpoint = this.getNextEndpoint();
      return await SigningStargateClient.connectWithSigner(endpoint, wallet);
    } catch (error) {
      console.error('Failed to create signing client:', error);
      throw new Error('Unable to connect to the network. Please try again.');
    }
  }

  private static async estimateGas(
    client: SigningStargateClient,
    fromAddress: string,
    toAddress: string,
    amount: string
  ): Promise<number> {
    try {
      const amountInUtia = Math.floor(parseFloat(amount) * Math.pow(10, CELESTIA_NETWORK.coinDecimals));
      
      const simulatedTx = await client.simulate(
        fromAddress,
        [{
          typeUrl: "/cosmos.bank.v1beta1.MsgSend",
          value: {
            fromAddress,
            toAddress,
            amount: [{
              denom: CELESTIA_NETWORK.coinMinimalDenom,
              amount: amountInUtia.toString()
            }]
          }
        }],
        ""
      );

      return Math.ceil(simulatedTx * this.gasMultiplier);
    } catch (error) {
      console.error('Gas estimation error:', error);
      throw new Error('Failed to estimate transaction fees. Please try again.');
    }
  }

  static async sendTokens({
    fromAddress,
    toAddress,
    amount,
    memo = ""
  }: SendTokensParams): Promise<TransactionResult> {
    const mnemonic = localStorage.getItem('wallet_mnemonic');
    if (!mnemonic) {
      throw new Error('Wallet not found. Please create or import a wallet first.');
    }

    try {
      const client = await this.getSigningClient(mnemonic);
      
      // Convert TIA to utia (microTIA)
      const amountInUtia = Math.floor(parseFloat(amount) * Math.pow(10, CELESTIA_NETWORK.coinDecimals));

      // Estimate gas
      const gasEstimate = await this.estimateGas(client, fromAddress, toAddress, amount);

      // Get current height for timeout
      const currentHeight = await client.getHeight();
      
      // Send transaction
      const result = await client.sendTokens(
        fromAddress,
        toAddress,
        [{
          denom: CELESTIA_NETWORK.coinMinimalDenom,
          amount: amountInUtia.toString()
        }],
        {
          amount: [{
            denom: CELESTIA_NETWORK.coinMinimalDenom,
            amount: Math.ceil(gasEstimate * CELESTIA_NETWORK.gasPrice).toString()
          }],
          gas: gasEstimate.toString()
        },
        memo,
        { timeoutHeight: currentHeight + this.timeoutHeight }
      );

      if (!result?.transactionHash) {
        throw new Error('Transaction failed. No hash returned.');
      }

      return {
        hash: result.transactionHash,
        height: result.height
      };
    } catch (error: any) {
      console.error('Transaction error:', error);
      if (error.message.includes('insufficient funds')) {
        throw new Error('Insufficient funds to cover transaction fees.');
      }
      throw new Error(error.message || 'Failed to send transaction. Please try again.');
    }
  }
}