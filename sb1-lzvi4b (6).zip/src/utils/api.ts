import { CELESTIA_NETWORK } from './constants';

export async function fetchBalance(address: string): Promise<string> {
  if (!address) return '0.000000';

  try {
    const response = await fetch(`${CELESTIA_NETWORK.restEndpoint}/cosmos/bank/v1beta1/balances/${address}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    // Handle case where balances array is empty or undefined
    if (!data?.balances?.length) {
      return '0.000000';
    }

    const tiaBalance = data.balances.find((b: any) => b?.denom === CELESTIA_NETWORK.coinMinimalDenom);
    
    if (!tiaBalance?.amount) {
      return '0.000000';
    }

    // Ensure we're parsing a valid number
    const amount = parseInt(tiaBalance.amount, 10);
    if (isNaN(amount)) {
      console.warn('Invalid balance amount:', tiaBalance.amount);
      return '0.000000';
    }

    // Convert from utia (microTIA) to TIA with 6 decimal places
    return (amount / Math.pow(10, CELESTIA_NETWORK.coinDecimals)).toFixed(6);
  } catch (error) {
    console.error('Error fetching balance:', error);
    // Return 0 instead of throwing to prevent UI disruption
    return '0.000000';
  }
}