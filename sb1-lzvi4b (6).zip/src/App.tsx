import React, { useState, useEffect } from 'react';
import { Wallet, Layout, Send, QrCode, Plus, Import, LogOut, History, FileCode } from 'lucide-react';
import CreateWallet from './components/CreateWallet';
import ImportWallet from './components/ImportWallet';
import SendTokens from './components/SendTokens';
import ReceiveTokens from './components/ReceiveTokens';
import WalletBalance from './components/WalletBalance';
import TransactionHistory from './components/TransactionHistory';
import HomePage from './components/HomePage';
import TechnicalDocs from './components/TechnicalDocs';

type Tab = 'create' | 'import' | 'send' | 'receive' | 'balance' | 'history' | 'docs';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('balance');
  const [address, setAddress] = useState<string>('');
  const [balance, setBalance] = useState<string>('0.000000');
  const [showHome, setShowHome] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const savedAddress = localStorage.getItem('wallet_address');
    if (savedAddress) {
      setAddress(savedAddress);
      setShowHome(false);
    }
  }, []);

  const handleWalletCreated = (newAddress: string, mnemonic: string) => {
    localStorage.setItem('wallet_address', newAddress);
    localStorage.setItem('wallet_mnemonic', mnemonic);
    setAddress(newAddress);
    setActiveTab('balance');
  };

  const handleBalanceUpdate = (newBalance: string) => {
    setBalance(newBalance);
  };

  const handleLoadingChange = (loading: boolean) => {
    setIsLoading(loading);
  };

  const handleLogout = () => {
    localStorage.removeItem('wallet_address');
    localStorage.removeItem('wallet_mnemonic');
    setAddress('');
    setBalance('0.000000');
    setActiveTab('balance');
    setShowHome(true);
  };

  if (showHome) {
    return <HomePage onAccept={() => setShowHome(false)} />;
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="bg-gray-800 p-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Wallet className="w-6 h-6 text-blue-400" />
          <span className="text-xl font-bold">Celestia Wallet</span>
        </div>
        {address && (
          <button
            onClick={handleLogout}
            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        )}
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-7 gap-4 mb-8">
          <button
            onClick={() => setActiveTab('create')}
            className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
              activeTab === 'create' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
            } ${!!address ? 'opacity-50 cursor-not-allowed' : ''}`}
            disabled={!!address}
          >
            <Plus className="w-5 h-5" />
            <span>Create</span>
          </button>
          <button
            onClick={() => setActiveTab('import')}
            className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
              activeTab === 'import' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
            } ${!!address ? 'opacity-50 cursor-not-allowed' : ''}`}
            disabled={!!address}
          >
            <Import className="w-5 h-5" />
            <span>Import</span>
          </button>
          <button
            onClick={() => setActiveTab('balance')}
            className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
              activeTab === 'balance' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <Layout className="w-5 h-5" />
            <span>Balance</span>
          </button>
          <button
            onClick={() => setActiveTab('send')}
            className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
              activeTab === 'send' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <Send className="w-5 h-5" />
            <span>Send</span>
          </button>
          <button
            onClick={() => setActiveTab('receive')}
            className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
              activeTab === 'receive' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <QrCode className="w-5 h-5" />
            <span>Receive</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
              activeTab === 'history' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <History className="w-5 h-5" />
            <span>History</span>
          </button>
          <button
            onClick={() => setActiveTab('docs')}
            className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
              activeTab === 'docs' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <FileCode className="w-5 h-5" />
            <span>Docs</span>
          </button>
        </div>

        <div className="bg-gray-800 rounded-lg p-8">
          {activeTab === 'create' && !address && <CreateWallet onWalletCreated={handleWalletCreated} />}
          {activeTab === 'import' && !address && <ImportWallet onWalletImported={handleWalletCreated} />}
          {activeTab === 'balance' && (
            <WalletBalance 
              address={address} 
              balance={balance} 
              onBalanceUpdate={handleBalanceUpdate}
              onLoadingChange={handleLoadingChange}
            />
          )}
          {activeTab === 'send' && <SendTokens address={address} balance={balance} />}
          {activeTab === 'receive' && <ReceiveTokens address={address} />}
          {activeTab === 'history' && <TransactionHistory address={address} />}
          {activeTab === 'docs' && <TechnicalDocs />}
        </div>
      </div>
    </div>
  );
}

export default App;